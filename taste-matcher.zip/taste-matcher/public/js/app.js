/* ─── Constants ─────────────────────────────────────────────────────────────── */

const IMAGE_BASE = 'https://image.tmdb.org/t/p/w342';

const defaultMessage = `
  <section class="hero">
    <div class="hero-badge">Taste Matcher · v2</div>
    <h2 class="hero-title">
      Turn your chaotic watchlist into a<br/>
      <span>perfectly ranked queue.</span>
    </h2>
    <p class="hero-subtitle">
      Built from your Letterboxd ratings + TMDb data. Use the actions above to explore:
    </p>
    <ul class="hero-list">
      <li>
        <span>🎬</span>
        <div>
          <strong>Ranked Watchlist</strong>
          <p>Every film in your watchlist ordered by predicted enjoyment.</p>
        </div>
      </li>
      <li>
        <span>🔁</span>
        <div>
          <strong>Ranked Rewatches</strong>
          <p>Films you've seen, sorted by rewatch-worthiness. Your rating is the anchor.</p>
        </div>
      </li>
      <li>
        <span>📊</span>
        <div>
          <strong>Genre Profile</strong>
          <p>See which genres you actually reward with the highest ratings.</p>
        </div>
      </li>
    </ul>
    <p class="hero-footer">
      Start with <strong>"Show Ranked Watchlist"</strong> to see what to watch tonight.
    </p>
  </section>
`;

/* ─── State ──────────────────────────────────────────────────────────────────── */

let allRecommendations = [];
let currentGenreTitles = [];

/* ─── DOM helpers ────────────────────────────────────────────────────────────── */

function setOutput(html) { document.getElementById('output').innerHTML = html; }
function goHome()        { setOutput(defaultMessage); }

document.getElementById('backButton').addEventListener('click', goHome);

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
}

/* ─── Score breakdown pill ───────────────────────────────────────────────────── */

function breakdownHtml(bd) {
  if (!bd) return '';
  const labels = { genre:'Genre', director:'Director', writer:'Writer', keyword:'Keywords', geography:'Geography', decade:'Decade', collection:'Collection', tmdb:'TMDb', neighbor:'Neighbors' };
  const entries = Object.entries(bd)
    .filter(([,v]) => v > 0)
    .sort(([,a],[,b]) => b-a)
    .slice(0, 5);
  if (!entries.length) return '';
  const pills = entries.map(([k,v]) =>
    `<span class="breakdown-pill">${labels[k]||k}: ${Math.round(v*100)}%</span>`
  ).join('');
  return `<div class="breakdown-row">${pills}</div>`;
}

/* ─── Card builder ───────────────────────────────────────────────────────────── */

function buildCard({ posterPath, title, year, genres, tmdbRating, letterboxdUrl, extraMeta, priorityHtml, actionBtns }) {
  const img = posterPath ? IMAGE_BASE + posterPath : null;
  const rating = typeof tmdbRating === 'number' ? tmdbRating.toFixed(1) : tmdbRating || '';
  return `
    <div class="card">
      ${img ? `<img class="poster" src="${img}" alt="Poster of ${escapeHtml(title)}" loading="lazy">` : '<div class="no-poster">No poster</div>'}
      <div class="card-main">
        <div>
          <div class="title-row">
            <div class="title">${escapeHtml(title)}</div>
            ${year ? `<div class="year">(${escapeHtml(year)})</div>` : ''}
          </div>
          ${genres?.length ? `<div class="genres">${escapeHtml(genres.join(', '))}</div>` : ''}
          <div class="meta">
            ${rating ? `<span>TMDb: ${rating}/10</span>` : ''}
            ${extraMeta || ''}
          </div>
          ${letterboxdUrl ? `<div style="font-size:11px;margin-top:4px;">
            <a class="movie-link" href="${escapeHtml(letterboxdUrl)}" target="_blank" rel="noopener noreferrer">View on Letterboxd ↗</a>
          </div>` : ''}
        </div>
        <div class="priority-row">
          ${priorityHtml || ''}
          ${actionBtns ? `<div style="margin-top:8px;display:flex;flex-wrap:wrap;gap:6px;">${actionBtns}</div>` : ''}
        </div>
      </div>
    </div>
  `;
}

/* ─── Reload & Reset ─────────────────────────────────────────────────────────── */

async function reloadWatchlist() {
  setOutput('<p class="summary">Reloading watchlist.csv…</p>');
  try {
    const data = await apiPost('/api/reload-watchlist');
    if (data.error) { alert('Error: ' + data.error); return; }
    alert(`Watchlist reloaded. Items: ${data.watchlistCount}, rewatches: ${data.overlapCount}.`);
    loadRecommendations();
  } catch (e) { alert('Failed to reload watchlist.'); }
}

async function resetState() {
  if (!confirm('Reset to original CSV files? This discards all manual changes.')) return;
  setOutput('<p class="summary">Resetting…</p>');
  try {
    const data = await apiPost('/api/reset-state');
    if (data.error) { alert('Error: ' + data.error); return; }
    alert(`State reset. Ratings: ${data.ratingsCount}, watchlist: ${data.watchlistCount}.`);
    loadRecommendations();
  } catch (e) { alert('Failed to reset state.'); }
}

/* ─── Rewatch Ranking ────────────────────────────────────────────────────────── */

async function loadRewatchRanking() {
  setOutput('<p class="summary">Loading ranked rewatches…</p>');
  try {
    const data = await apiFetch('/api/rewatch-ranking');
    const items = data.items || [];
    if (!items.length) { setOutput('<p class="summary">No rewatches found.</p>'); return; }

    let html = `<h3>Ranked Rewatches</h3>
      <p class="summary">${data.count} rewatch candidates. Rating is the primary anchor; the taste model adjusts by up to ±30%.</p>
      <div class="cards">`;

    items.forEach((r, i) => {
      const pct = Math.round(r.rewatchScore * 100);
      html += buildCard({
        posterPath: r.posterPath, title: r.title, year: r.year,
        genres: r.genres, tmdbRating: r.tmdbRating, letterboxdUrl: r.letterboxdUrl,
        extraMeta: `<span>Your rating: ${r.userRating}★</span><span>Model score: ${Math.round(r.modelScore*100)}%</span>`,
        priorityHtml: `
          <div class="priority-label">Rewatch priority: ${pct}%</div>
          <div class="bar-wrap"><div class="bar-fill" style="width:${pct}%;"></div></div>
          <div class="priority-text">Rewatch rank #${i+1}</div>
          ${breakdownHtml(r.breakdown)}
        `,
        actionBtns: r.letterboxdUrl ? `
          <button class="small-btn hide-rewatch-btn"
            data-url="${escapeHtml(r.letterboxdUrl)}"
            data-title="${escapeHtml(r.title)}">
            Hide from rewatches
          </button>` : ''
      });
    });

    html += '</div>';
    setOutput(html);
    attachHideRewatchHandlers();
  } catch (e) { setOutput('<p class="summary">Failed to load rewatches.</p>'); }
}

function attachHideRewatchHandlers() {
  document.querySelectorAll('.hide-rewatch-btn').forEach(btn => {
    btn.addEventListener('click', async e => {
      const url   = e.currentTarget.dataset.url;
      const title = e.currentTarget.dataset.title;
      if (!confirm(`Hide "${title}" from your rewatch list?`)) return;
      try {
        const data = await apiPost('/api/hide-rewatch', { letterboxdUrl: url });
        if (data.error) { alert('Error: ' + data.error); return; }
        loadRewatchRanking();
      } catch (e) { alert('Failed to hide rewatch.'); }
    });
  });
}

/* ─── Genre Profile ──────────────────────────────────────────────────────────── */

async function loadGenreProfile() {
  setOutput('<p class="summary">Building genre profile…</p>');
  try {
    const data = await apiFetch('/api/genre-profile');
    const stats   = data.genreStats   || {};
    const profile = data.genreProfile || {};

    const entries = Object.keys(stats).map(id => ({
      id, name: stats[id].name, avg: profile[id] || 0, count: stats[id].count
    })).sort((a,b) => b.avg - a.avg);

    if (!entries.length) { setOutput('<p>No genre data available.</p>'); return; }
    const maxAvg = Math.max(...entries.map(e => e.avg));

    let html = `<h3>Genre Profile</h3>
      <p class="summary">Based on ${data.usedRatings} rated titles. Click a genre to see films in it.</p>
      <div class="genre-grid">`;

    entries.forEach(e => {
      const pct = maxAvg > 0 ? Math.round((e.avg / maxAvg) * 100) : 0;
      html += `
        <div class="genre-card" onclick="loadGenreTitles(${e.id})">
          <div class="genre-name">${escapeHtml(e.name)}</div>
          <div>Smoothed avg: ${e.avg.toFixed(2)} / 5</div>
          <div>Titles rated: ${e.count}</div>
          <div class="genre-bar-wrap"><div class="genre-bar-fill" style="width:${pct}%;"></div></div>
        </div>`;
    });

    html += '</div>';
    setOutput(html);
  } catch (e) { setOutput('<p class="summary">Failed to load genre profile.</p>'); }
}

async function loadGenreTitles(genreId) {
  setOutput('<p class="summary">Loading genre titles…</p>');
  try {
    const data = await apiFetch('/api/genre-titles/' + genreId);
    currentGenreTitles = data.items || [];

    if (!currentGenreTitles.length) {
      setOutput(`<h3>Genre ${genreId}</h3><p class="summary">No rated titles in this genre.</p>`);
      return;
    }

    setOutput(`
      <h3>Genre – rated titles</h3>
      <p class="summary">${currentGenreTitles.length} films rated in this genre.</p>
      <div class="search-wrap">
        <input id="genreTitlesSearch" type="text" placeholder="Search by title…" />
      </div>
      <div id="genreTitlesCards" class="cards"></div>
    `);

    const cardsDiv = document.getElementById('genreTitlesCards');
    function render(list) {
      cardsDiv.innerHTML = list.map(r => buildCard({
        posterPath: r.posterPath, title: r.title, year: r.year,
        genres: r.genres, tmdbRating: r.tmdbRating, letterboxdUrl: r.letterboxdUrl,
        extraMeta: `<span>Your rating: ${r.userRating}★</span>`
      })).join('') || '<p class="summary">No results.</p>';
    }

    render(currentGenreTitles);
    document.getElementById('genreTitlesSearch').addEventListener('input', e => {
      const q = e.target.value.toLowerCase().trim();
      render(q ? currentGenreTitles.filter(r => (r.title||'').toLowerCase().includes(q)) : currentGenreTitles);
    });
  } catch (e) { setOutput('<p class="summary">Failed to load genre titles.</p>'); }
}

/* ─── Recommendations ────────────────────────────────────────────────────────── */

function renderRecommendations(list) {
  const cardsDiv = document.getElementById('recsCards');
  if (!cardsDiv) return;

  if (!list?.length) {
    cardsDiv.innerHTML = '<p class="summary">No recommendations to show.</p>';
    return;
  }

  cardsDiv.innerHTML = list.map(r => {
    const pct  = Math.round(r.predictedScore * 100);
    const rank = r.globalRank ?? (allRecommendations.indexOf(r) + 1);

    const actionBtns = r.letterboxdUrl ? `
      <button class="small-btn mark-watched-btn"
        data-url="${escapeHtml(r.letterboxdUrl)}"
        data-title="${escapeHtml(r.title)}"
        data-year="${escapeHtml(r.year||'')}">
        Mark watched &amp; rate
      </button>
      <button class="small-btn remove-watchlist-btn"
        data-url="${escapeHtml(r.letterboxdUrl)}"
        data-title="${escapeHtml(r.title)}">
        Remove from watchlist
      </button>` : '';

    return buildCard({
      posterPath: r.posterPath, title: r.title, year: r.year,
      genres: r.genres, tmdbRating: r.tmdbRating, letterboxdUrl: r.letterboxdUrl,
      extraMeta: `<span>Model score: ${Math.round(r.predictedScore*100)}%</span>${r.directors?.length ? `<span>Dir: ${escapeHtml(r.directors.slice(0,2).join(', '))}</span>` : ''}`,
      priorityHtml: `
        <div class="priority-label">Match: ${pct}%</div>
        <div class="bar-wrap"><div class="bar-fill" style="width:${pct}%;"></div></div>
        <div class="priority-text">Rank #${rank} in your watchlist</div>
        ${breakdownHtml(r.breakdown)}
      `,
      actionBtns
    });
  }).join('');

  attachMarkWatchedHandlers();
  attachRemoveWatchlistHandlers();
}

function attachMarkWatchedHandlers() {
  document.querySelectorAll('.mark-watched-btn').forEach(btn => {
    btn.addEventListener('click', async e => {
      const b    = e.currentTarget;
      const url  = b.dataset.url;
      const title = b.dataset.title;
      const year  = b.dataset.year ? parseInt(b.dataset.year, 10) : null;

      if (!url) { alert('No Letterboxd URL.'); return; }
      const rs = window.prompt(`Your rating for "${title}" (0–5, half-stars OK):`);
      if (rs == null) return;
      const rating = parseFloat(rs);
      if (isNaN(rating) || rating < 0 || rating > 5) { alert('Enter a number 0–5.'); return; }

      try {
        const data = await apiPost('/api/mark-watched', { letterboxdUrl: url, rating, title, year });
        if (data.error) { alert('Error: ' + data.error); return; }
        alert('Saved. Refreshing recommendations.');
        loadRecommendations();
      } catch (e) { alert('Failed to mark watched.'); }
    });
  });
}

function attachRemoveWatchlistHandlers() {
  document.querySelectorAll('.remove-watchlist-btn').forEach(btn => {
    btn.addEventListener('click', async e => {
      const b    = e.currentTarget;
      const url  = b.dataset.url;
      const title = b.dataset.title;
      if (!confirm(`Remove "${title}" from watchlist?`)) return;
      try {
        const data = await apiPost('/api/remove-from-watchlist', { letterboxdUrl: url });
        if (data.error) { alert('Error: ' + data.error); return; }
        loadRecommendations();
      } catch (e) { alert('Failed to remove.'); }
    });
  });
}

async function loadRecommendations() {
  setOutput('<p class="summary">Calculating recommendations (first call may take a while)…</p>');
  try {
    const data = await apiFetch('/api/recommendations');
    allRecommendations = data.recommendations || [];

    if (!allRecommendations.length) { setOutput('<p>No recommendations computed.</p>'); return; }
    allRecommendations.forEach((r, i) => { r.globalRank = i + 1; });

    setOutput(`
      <h3>Ranked Watchlist</h3>
      <p class="summary">
        ${data.totalRatings} ratings used for taste profile.
        ${data.totalWatchlist} watchlist items ranked.
        ${data.overlapCount} rewatches removed.
      </p>
      <div class="search-wrap">
        <input id="recsSearch" type="text" placeholder="Search by title or genre…" />
      </div>
      <div class="filters-row">
        <input id="filterYear"   type="text" class="filter-input" placeholder="Year (e.g. 2019)" />
        <input id="filterDecade" type="text" class="filter-input" placeholder="Decade (e.g. 1990s)" />
        <select id="filterDirector" class="filter-select">
          <option value="all">All directors</option>
          <option value="watched">Only watched directors</option>
          <option value="unwatched">Only new directors</option>
        </select>
        <button class="pill-btn" id="applyFiltersBtn">Apply filters</button>
        <button class="pill-btn ghost" id="clearFiltersBtn">Clear</button>
      </div>
      <div id="recsCards" class="cards"></div>
    `);

    const searchInput   = document.getElementById('recsSearch');
    const yearInput     = document.getElementById('filterYear');
    const decadeInput   = document.getElementById('filterDecade');
    const dirSelect     = document.getElementById('filterDirector');
    const applyBtn      = document.getElementById('applyFiltersBtn');
    const clearBtn      = document.getElementById('clearFiltersBtn');

    function applyFilters() {
      const q       = searchInput.value.toLowerCase().trim();
      const yearStr = yearInput.value.trim();
      const decStr  = decadeInput.value.trim();
      const dirMode = dirSelect.value;
      let filtered  = allRecommendations.slice();

      if (q) filtered = filtered.filter(r =>
        (r.title||'').toLowerCase().includes(q) || (r.genres||[]).some(g => g.toLowerCase().includes(q))
      );

      if (yearStr) {
        const y = parseInt(yearStr, 10);
        if (isNaN(y) || y < 1888 || y > 2100) { alert('Invalid year.'); return; }
        filtered = filtered.filter(r => parseInt(r.year, 10) === y);
      }

      if (decStr) {
        const m = decStr.match(/^(\d{4})s$/i);
        if (!m) { alert('Use format like "1990s".'); return; }
        const start = parseInt(m[1], 10);
        filtered = filtered.filter(r => { const y = parseInt(r.year,10); return y>=start && y<=start+9; });
      }

      if (dirMode === 'watched')   filtered = filtered.filter(r => r.hasWatchedDirector);
      if (dirMode === 'unwatched') filtered = filtered.filter(r => !r.hasWatchedDirector);

      const container = document.getElementById('recsCards');
      if (!filtered.length) { container.innerHTML = '<p class="summary">No titles match the current filters.</p>'; }
      else renderRecommendations(filtered);
    }

    searchInput.addEventListener('input', applyFilters);
    applyBtn.addEventListener('click', applyFilters);
    clearBtn.addEventListener('click', () => {
      searchInput.value = ''; yearInput.value = ''; decadeInput.value = ''; dirSelect.value = 'all';
      renderRecommendations(allRecommendations);
    });

    renderRecommendations(allRecommendations);
  } catch (e) { setOutput('<p class="summary">Failed to load recommendations.</p>'); console.error(e); }
}

/* ─── Manual mutations ───────────────────────────────────────────────────────── */

async function promptAddRating() {
  const tmdbInput = window.prompt('TMDb URL or ID (recommended, or leave blank):');
  const title     = window.prompt('Film/series title (overridden if TMDb is given):');
  const yearStr   = window.prompt('Year (optional):');
  const year      = yearStr ? parseInt(yearStr, 10) : null;
  const lbUrl     = window.prompt('Letterboxd URL (optional):');
  const ratingStr = window.prompt('Your rating (0–5, half-stars OK):');
  if (ratingStr == null) return;
  const rating = parseFloat(ratingStr);
  if (isNaN(rating) || rating < 0 || rating > 5) { alert('Enter a number 0–5.'); return; }

  try {
    const data = await apiPost('/api/add-rating', { title, year, letterboxdUrl: lbUrl, rating, tmdbInput });
    if (data.error) { alert(data.alreadyRated ? 'Already rated.' : 'Error: ' + data.error); return; }
    alert('Rating added. Reload the ranked watchlist/rewatches to see changes.');
  } catch (e) { alert('Failed to add rating.'); }
}

async function promptAddToWatchlist() {
  const tmdbInput = window.prompt('TMDb URL or ID (recommended, or leave blank):');
  const title     = window.prompt('Film/series title (overridden if TMDb is given):');
  const yearStr   = window.prompt('Year (optional):');
  const year      = yearStr ? parseInt(yearStr, 10) : null;
  const lbUrl     = window.prompt('Letterboxd URL (required):');
  if (!lbUrl) { alert('Letterboxd URL is required.'); return; }

  try {
    const data = await apiPost('/api/add-to-watchlist', { title, year, letterboxdUrl: lbUrl, tmdbInput });
    if (data.error) {
      if (data.rewatch) { alert('Note: ' + data.error); return; }
      alert('Error: ' + data.error); return;
    }
    alert('Added to watchlist!');
    loadRecommendations();
  } catch (e) { alert('Failed to add to watchlist.'); }
}

/* ─── FIX: Export now triggers a direct browser download ─────────────────────── */

async function exportRankedWatchlist() {
  const includeRewatches = confirm(
    'Include rewatches in the exported list?\n\nOK = yes, Cancel = watchlist only.'
  );

  try {
    const url = `/api/export-ranked-watchlist?includeRewatches=${includeRewatches}`;
    const res = await fetch(url);

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      alert('Error: ' + (err.error || 'Unknown error'));
      return;
    }

    // Trigger browser download directly from the streamed CSV
    const blob     = await res.blob();
    const blobUrl  = URL.createObjectURL(blob);
    const a        = document.createElement('a');
    const today    = new Date().toISOString().slice(0, 10);
    a.href         = blobUrl;
    a.download     = `ranked-watchlist-${today}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(blobUrl);
    alert(`Exported! Import this CSV into Letterboxd via Lists → Import.\n${includeRewatches ? 'Rewatches included.' : 'Watchlist only.'}`);
  } catch (e) { alert('Failed to export.'); console.error(e); }
}

/* ─── API helpers ────────────────────────────────────────────────────────────── */

async function apiFetch(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

async function apiPost(url, body = {}) {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  return res.json();
}

/* ─── Init ───────────────────────────────────────────────────────────────────── */

goHome();
